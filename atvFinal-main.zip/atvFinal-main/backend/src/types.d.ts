import type { TSchema  } from "elysia/types";

export type USER_ROLES = "ADMIN" | "USER";